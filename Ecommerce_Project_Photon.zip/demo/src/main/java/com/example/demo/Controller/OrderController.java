package com.example.demo.Controller;

import com.example.demo.Entity.Product;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/Ecommerce")
public class OrderController {

    @PostMapping("/orders")
    public void createOrder(@RequestBody Product product){
        createOrder(product);
    }

    @GetMapping("/products/{id}")
    public Product getProductDetails(@PathVariable int id){
               Product product = getProductDetails(id);
               return product;
    }
}
