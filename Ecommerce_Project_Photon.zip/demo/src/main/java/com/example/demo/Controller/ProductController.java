package com.example.demo.Controller;

import com.example.demo.Entity.Product;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/Ecommerce")
public class ProductController {

    @GetMapping("/products")
    public List<Product> getAllProducts(){

        List<Product> productList = getAllProducts();
        return productList;
    }

    @GetMapping("/products/{id}")
    public Product getProductById(@PathVariable int id) {
        Product product = getProductById(id);
        return product;
    }

}
