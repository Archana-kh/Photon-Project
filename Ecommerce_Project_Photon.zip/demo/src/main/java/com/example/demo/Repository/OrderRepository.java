package com.example.demo.Repository;

import com.example.demo.Entity.Product;

public interface OrderRepository {
    void createOrder(Product product);
    Product getProductDetails(int id);
}
