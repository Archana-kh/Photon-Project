package com.example.demo.Repository;

import com.example.demo.Entity.Product;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository{

    @Bean
    List<Product> getAllProducts();

    @Bean
    Product getProductById(int id);

}
