package com.example.demo.Service;

import com.example.demo.Entity.Product;
import com.example.demo.Repository.OrderRepository;

public class OrderService implements OrderRepository {

    @Override
    public void createOrder(Product product) {

    }

    @Override
    public Product getProductDetails(int id) {
        return null;
    }
}
