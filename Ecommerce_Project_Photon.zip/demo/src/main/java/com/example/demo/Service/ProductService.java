package com.example.demo.Service;

import com.example.demo.Entity.Product;
import com.example.demo.Repository.ProductRepository;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public class ProductService implements ProductRepository {

    private JpaRepository jpaRepository;
    private Product product;

    @Override
    public List<Product> getAllProducts() {
        return List.of();
    }

    @Override
    public Product getProductById(int id) {
        return null;
    }

//    private ProductRepository productRepository;



}
